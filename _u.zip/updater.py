import zipfile
import wget
import os
wget.download('https://atarwn.github.io/abl/u.zip')
with zipfile.ZipFile('u.zip', 'r') as zip_c:
    zip_c.extractall('')
os. remove("u.zip")
